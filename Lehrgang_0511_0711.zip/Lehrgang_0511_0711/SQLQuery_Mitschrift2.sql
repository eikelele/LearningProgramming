/*
CREATE VIEW VW_OrdersWithPrice AS
SELECT
	B.bestnr,
	SUM(BP.menge*BP.preis*((100-BP.rabatt) / 100)) as Gesamt
FROM
	bestellungen AS B

INNER JOIN 
	lieferanten AS L ON B.lieferant = L.liefnr
INNER JOIN
	personal AS P ON B.bearbeiter = P.persnr
INNER JOIN
	bestellpositionen AS BP ON B.bestnr = BP.bestnr

GROUP BY
	B.bestnr
*/

--ORDER BY NUR BEI TOP(), OFFSET() ODER FROM XML
--Logisches und physikalisches l�schen: logisches l�schen beh�lt Lieferanten... Zusatzspalte mit gel�scht True
--Physikalisches l�schen: direktes l�schen
--Views erstellen f�r Abfragen die h�ufig genutzt werden

/*
SELECT
	*
FROM
	newest5_orders
*/

SELECT
	round(sum(Gesamt),2) AS GesamtSumme
FROM 
	VW_OrdersWithPrice


