--Abfrage 1
-- Kunden die einen Adresse haben und dazu die Richtige
SELECT
	kunden.nachname AS Nachname,
	kunden.vorname AS Vorname,
	adressen.strasse AS Stra�e,
	adressen.haus_nr,
	adressen.plz,
	adressen.ort
FROM
	kunden,
	adressen,
	kunden_adressen_rel
WHERE
	kunden.nr = kunden_adressen_rel.kunden_nr
AND
	adressen.nr = kunden_adressen_rel.adressen_nr
ORDER BY kunden.nachname

--Abfrage 2
SELECT 
	COUNT(*) AS Anzahl
FROM
	kunden

--Abfrage 3
SELECT 
	SUM(nr) AS Summe
FROM
	kunden
--Weitere Beispiele: MIN(), MAX(), AVG(), SUM(), COUNT(), CONCAT()
--Abfrage 4:
SELECT
	CONCAT(kunden.anrede, ' ', kunden.vorname, ' ', kunden.nachname) AS Briefanschrift
FROM
	kunden

--Abfrage 5:
SELECT
	COUNT(*) as Anzahl, kunden.nachname
FROM
	kunden
GROUP BY
	kunden.nachname

--Abfrage 6:
--DML!!!!
INSERT INTO
	kunden(vorname,nachname)
VALUES
	('Olaf','')

--Abfrage 7:
--DML!!!! UPDATES IMMER MIT EINEM WHERE
UPDATE
	adressen
SET
	plz = '99999'
WHERE
	nr = 1

--Abfrage 8:
--L�scht alle Datens�tze
DELETE
FROM
	adressen
--L�scht alle Datens�tze und setzt zur�ck
TRUNCATE TABLE
	adressen	
--L�scht Datens�tze samt Tabellenstruktur
DROP TABLE
	adressen

DROP DATABASE
	test

--CRUD: Create	Read	Update	Delete
--		Insert	Select	Update	Delete

--Historie: Artikeltabelle - Intelligente Art-Nr., oder nicht? ID PK, Art-Nr KEIN PK ABER mit Index (�nderbar), Beschreibung, Preis
--Art-Nr nicht als PK, damit man sie variablel verwalten kann
--Lebende Dinge bekommen einen Namen und tote Dinge eine Bezeichnung
--Preis kann unterschiedlich sein... Abh�ngigkeiten: Zeit (t)
--Es w�re sinnlos eine zust�zliche Tabelle anzulegen um die Preise einzeln zu halten... 1:n nicht n:m!
--1. Tabelle: nr, bezeichnung, beschreibung 2. Tabelle: nr,preis,zeit(ab) -> Zusammengesetzten Schl�ssel nr + zeit
--Abfrage 9: 

SELECT
	TOP (1)
	artikel.bezeichnung,
	preise.preis
FROM
	artikel, preise
WHERE
	artikel.nr = 10000
	AND artikel.nr = preise.artikel_nr
	AND preise.gueltig_ab < '05.11.2018'
ORDER BY
	preise.gueltig_ab DESC
--Kein UPDATE sondern ein INSERT auf die dbo.preise
--Data Tools in Visual Studio (SSIS/SSAS/SSRS)
--Neues Projekt / BI / Integration Services
--Import automatisiert
--Datenfluss : Ablaufsteuerung -> Datenfluss: Quell- und Zielassistent
--Excel-Import: Auf H�ckchen achten bei Spaltennamen und Blattregister ausw�hlen aus der Mappe
--Server, Tabelle, definieren und Zuordnungen checken
--Blauer Pfeil: Nicht fehlerhafte Daten
--Roter Pfeil: Fehlerhafte Daten
--Bennungen �ndern F2-Key
SELECT
	*
FROM
	dbo.Herren
--Bedingtes teilen in Herren und Frauen
--F�r Import eines Integration Services im Objekt-Explorer unter Integration Services-Kataloge einen Katalog anlegen
--Scale Out-Master aktivieren und verschiedenen Instanzen Pakete zuweisen
-- Unter SSISDB neuen Ordner anlegen... �bersicht behalten -> Dann Reiter "Projekt" und "Bereitstellen"!
--Wizard durchlaufen und Projekt in die erstellte Ordnerstruktur erstellen
--Server Agent: Auftrag das Paket zu starten -> "Auftr�ge" -> "Neuer Auftrag"
--Auftrag: Beschreiben und Schritte erstellen: Typ: "SQL Server IS-Pakete" und weitere Vorstellungen vornehmen
--Autrag: Zeitplan anlegen, Zeitplantyp "Wiederholt" aber auch wenn Leerlauf m�glich
--Auftrag: Warnungen und Benachrichtigungen m�glich

SELECT
	*
FROM
	dbo.Herren

--Rechtsklick dbo.OLE DB-Ziel und Skript f�r Tabelle als -> CREATE IN -> Neues Abfrage-Editor-Fenster
--Windows "Ereignisanzeige"
--Konvertierungswizard unter "Projekt" -> "Export/Import-Manager"
--Neues Projekt: WAWI-DB
--Kundenimport via SSIS... Folgende Reihenfolge: Anreden, Mitgliedschaften, Adressen, KD+ADR_REL

